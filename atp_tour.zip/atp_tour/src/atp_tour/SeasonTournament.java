package atp_tour;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Dejan Pejic
 */
public class SeasonTournament extends Tournament
{
	private ArrayList<Player> roundOf16;
	private ArrayList<Player> quarterFinalists;
	private ArrayList<Player> semiFinalists;
	private ArrayList<Player> finalists;
	
	public SeasonTournament(String tourName, String tourType, String tourSurface, boolean playable, ArrayList<Player> roundOf16)
	{
		super(tourName,tourType, tourSurface, playable);
		this.roundOf16 = roundOf16;
		this.quarterFinalists = new ArrayList<>();
		this.semiFinalists = new ArrayList<>();
		this.finalists = new ArrayList<>();
	}
	
	@Override
	public void play()
	{
		this.playRoundOf16();
		this.playQuarterFinals();
		this.playSemiFinals();
		this.playFinal();
	}
	
	private void playRoundOf16()
	{
		Match[] matches = new Match[8];
		Collections.shuffle(roundOf16);
		int points = tourType.equals("Masters1000") ? 100 : 180;
		
		for(Player pl : roundOf16)
			pl.setAtpPoints(pl.getAtpPoints() + points);
		
        System.out.println("=== " + tourName + " - Round of 16 ===");
		
		for (int i = 0; i < 8; i++)
		{
			matches[i] = new Match(roundOf16.get(2*i), roundOf16.get(2*i+1), 
						           tourSurface, numOfSets);
            
			quarterFinalists.add(matches[i].playMatch());
			matches[i].printMatchResult();
		}
		
		System.out.println();
	}
	
	private void playQuarterFinals()
	{
		Match[] matches = new Match[4];
		int points = tourType.equals("Masters1000") ? 100 : 180;
		
		for(Player pl : quarterFinalists)
			pl.setAtpPoints(pl.getAtpPoints() + points);
		
        System.out.println("=== " + tourName + " - Quarter Finals ===");
		
		for (int i = 0; i < 4; i++)
		{
			matches[i] = new Match(quarterFinalists.get(2*i), quarterFinalists.get(2*i+1), 
						           tourSurface, numOfSets);
            
			semiFinalists.add(matches[i].playMatch());
			matches[i].printMatchResult();
		}
		
		System.out.println();
	}
	
	private void playSemiFinals()
	{
		Match[] matches = new Match[2];
		int points = tourType.equals("Masters1000") ? 200 : 360;
		
		for(Player pl : semiFinalists)
			pl.setAtpPoints(pl.getAtpPoints() + points);
		
        System.out.println("==== " + tourName + " - Semi Finals ====");
		
		for (int i = 0; i < 2; i++)
		{
			matches[i] = new Match(semiFinalists.get(2*i), semiFinalists.get(2*i+1), 
						           tourSurface, numOfSets);
            
			finalists.add(matches[i].playMatch());
			matches[i].printMatchResult();
		}
		
		System.out.println();
	}

	private void playFinal()
	{
		int points = tourType.equals("Masters1000") ? 250 : 480;
		int winPoints = tourType.equals("Masters1000") ? 350 : 800;
		Player winner = new Player();
		
		for(Player pl : finalists)
			pl.setAtpPoints(pl.getAtpPoints() + points);
		
        System.out.println("===== " + tourName + " - Final =====");
		
		Match fm = new Match(finalists.get(0), finalists.get(1), tourSurface, numOfSets);
		winner = fm.playMatch();
		winner.setAtpPoints(winner.getAtpPoints() + winPoints);
		
		fm.printMatchResult();
		System.out.println("The " + tourName + "'s winner is " + winner.getName() + "! Congratulations!");
		
		System.out.println();
	}
	
	@Override
    public String toString()
    {
		String isPlayable = playable ? "" : " | x";
        return tourName + ", " + tourType + " (" + tourSurface + ")" + isPlayable;
    }
}	
