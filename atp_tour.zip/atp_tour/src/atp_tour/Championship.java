package atp_tour;

import java.util.ArrayList;
import java.util.Collections;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.Scanner;
import java.io.IOException;
import java.io.FileNotFoundException;

/**
 *
 * @author Dejan Pejic
 */
 public class Championship
 {
	private ArrayList<Player> players;
	private ArrayList<Tournament> tournaments;
	 
	public Championship()
	{
		 players = new ArrayList<>();
		 tournaments = new ArrayList<>();
	}
	
	public ArrayList<Player> getPlayers()
    {
		return players;
    }

    public void setPlayers(ArrayList<Player> players)
    {
		this.players = players;
    }
	
	public ArrayList<Tournament> getTournaments()
    {
		return tournaments;
    }

    public void setTournaments(ArrayList<Tournament> tournaments)
    {
		this.tournaments = tournaments;
    }
	
	public void updateAtpRanks()
	{
		Collections.sort(players);
		for (int i = 0; i < players.size(); i++)
			players.get(i).setAtpRank(i + 1);
	}
	
	public void recoverPlayers()
	{
		for (Player pl: players)
		{
			if (pl.getInjured())
				pl.setInjured(false);
		}
	}
	
	public void loadFiles() throws FileNotFoundException, IOException
	{
		Scanner sc = new Scanner(System.in);
		String str;
		String players_txt, tournaments_txt;
		File players_file, tournaments_file;
		
		System.out.print("Insert the location of the \"players.txt\" document: ");
		do 
		{
			players_txt = sc.nextLine();
			players_txt += "\\players.txt";
			
			players_file = new File(players_txt);
			if (!players_file.exists() || !players_file.isFile()) 
				System.out.print("Try again: ");
        } while (!players_file.exists() || !players_file.isFile());
		
		BufferedReader inputPlayers = new BufferedReader(new FileReader(players_txt));
		while ((str = inputPlayers.readLine()) != null)
		{
			String[] player_data = str.split(",");
			if (player_data.length != 5)
			{
				System.out.println("Wrong players data file format!");
				System.exit(0);
			}
			
			Player pl = new Player(player_data[1], player_data[2], player_data[3], Integer.parseInt(player_data[0]), Integer.parseInt(player_data[4]));
			players.add(pl);
		}
		
		System.out.print("Insert the location of the \"tournaments.txt\" document: ");
		do 
		{
			tournaments_txt = sc.nextLine();
			tournaments_txt += "\\tournaments.txt";
			
			tournaments_file = new File(tournaments_txt);
			if (!tournaments_file.exists() || !tournaments_file.isFile()) 
				System.out.print("Try again: ");
        } while (!tournaments_file.exists() || !tournaments_file.isFile());
		
		BufferedReader inputTournaments = new BufferedReader(new FileReader(tournaments_txt));
		while ((str = inputTournaments.readLine()) != null)
		{
			String[] tournament_data = str.split(",");
			if (tournament_data.length != 3)
			{
				System.out.println("Wrong tournaments data file format!");
				System.exit(0);
			}
			
			Tournament trn = new SeasonTournament(tournament_data[0], tournament_data[2], tournament_data[1], true, players);
			tournaments.add(trn);
		}
	}
 }
 
