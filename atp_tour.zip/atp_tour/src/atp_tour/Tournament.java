package atp_tour;

import java.util.ArrayList;

/**
 *
 * @author Dejan Pejic
 */
public abstract class Tournament
{
	protected String tourName;
	protected String tourType;
	protected String tourSurface;
	protected boolean playable;
	protected int numOfSets;
	protected ArrayList<Player> contestants;
	
	public Tournament(String tourName, String tourType, String tourSurface, boolean playable)
	{
		this.tourName = tourName;
		this.tourType = tourType;
		this.tourSurface = tourSurface;
		this.playable = playable;
		this.numOfSets = tourType.equals("Grand Slam") ? 3 : 2;
	}
	
	public String getTourName()
    {
		return tourName;
    }
	
	public void setTourName(String tourName) 
	{
        this.tourName = tourName;
    }
	
	public String getTourType()
    {
		return tourType;
    }
	
	public void setTourType(String tourType) 
	{
        this.tourType = tourType;
    }
	
	public boolean getPlayable()
    {
		return playable;
    }

    public void setPlayable(boolean playable)
    {
		this.playable = playable;
    }
	
	public abstract void play();
}