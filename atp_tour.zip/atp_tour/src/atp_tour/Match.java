package atp_tour;

import java.util.Random;

/**
 *
 * @author Dejan Pejic
 */
public class Match
{
    private Player p1;
    private Player p2;
    private String matchSurface;
    private int winSetNum;
    private int p1Sets, p1Gems, p2Sets, p2Gems;
    private int p1ScorePerSet[], p2ScorePerSet[];
    private Random rng;

    public Match(Player p1, Player p2, String matchSurface, int winSetNum)
    {
        this.p1 = p1;
        this.p2 = p2;
        this.matchSurface = matchSurface;
        this.winSetNum = winSetNum;
        this.p1Sets = 0;
        this.p2Sets = 0;
        this.p1Gems = 0;
        this.p2Gems = 0;
        this.p1ScorePerSet = new int[2*winSetNum - 1];
        this.p2ScorePerSet = new int[2*winSetNum - 1];
        this.rng = new Random();
    }

    public Player playMatch()
    {
        int currentSet = 0;
		
		if (1 + this.rng.nextInt(100) == 66 && !p1.getInjured() && !p2.getInjured())
		{
			if (this.rng.nextInt(2) == 1)
			{
				this.p1.setInjured(true);
				System.out.println("Unfortunately, " + p1.getName() + " got injured, so he withdraws from the competition.\n");
			}
			else
			{
				this.p2.setInjured(true);
				System.out.println("Unfortunately, " + p2.getName() + " got injured, so he withdraws from the competition.\n");
			}
		}
		
		if (this.p1.getInjured())
			return this.p2;
		else if (this.p2.getInjured())
			return this.p1;

        while (this.p1Sets < this.winSetNum && this.p2Sets < this.winSetNum)
        {
			this.playSet();

			this.p1ScorePerSet[currentSet] = this.p1Gems;
			this.p2ScorePerSet[currentSet] = this.p2Gems;
			currentSet++;
        }

        if (this.p1Sets == this.winSetNum)
			return this.p1;
        else
			return this.p2;
    }

    private void playSet()
    {
        this.p1Gems = 0;
        this.p2Gems = 0;

        while (this.p1Gems < 6 && this.p2Gems < 6)
			this.playGame();

        if (this.p1Gems == 6)
        {
            if (this.p2Gems <= 4)
            {
                this.p1Sets++;
                return;
            }
            else
                    this.playGame();

            if (this.p1Gems == 7)
            {
                this.p1Sets++;
                return;
            }
        }
        else
        {
            if (this.p1Gems <= 4)
            {
                this.p2Sets++;
                return;
            }
            else
                this.playGame();

            if (this.p2Gems == 7)
            {
                this.p2Sets++;
                return;
            }
        }

        this.playTieBreak();

        if (this.p1Gems == 7)
            this.p1Sets++;
        else
            this.p2Sets++;
    }

    private void playGame()
    {
        int points[] = {0, 15, 30, 40};
        int p1Points = 0;
        int p2Points = 0;
        int tmp1 = 0;
        int tmp2 = 0;

        if ((this.p1Gems + this.p2Gems) % 2 == 0)
        {
            while ((p1Points < 40 && p2Points < 40) || (Math.abs(p1Points - p2Points) < 2 && Math.abs(tmp1 - tmp2) < 2))
            {
                if (this.chanceEvent(this.p1.servePointChance(this.p2, this.matchSurface)))
                {
                    if (tmp1 < 3)
                    {
						tmp1++;
						p1Points = points[tmp1];
                    }
                    else
						p1Points++;
                }
                else
                {
                    if (tmp2 < 3)
                    {
						tmp2++;
						p2Points = points[tmp2];
                    }
                    else
						p2Points++;
                }
            }	
        }
        else
        {
            while ((p1Points < 40 && p2Points < 40) || (Math.abs(p1Points - p2Points) < 2 && Math.abs(tmp1 - tmp2) < 2))
            {
                if (this.chanceEvent(this.p2.servePointChance(this.p1, this.matchSurface)))
                {
                    if (tmp2 < 3)
                    {
						tmp2++;
						p2Points = points[tmp2];
                    }
                    else
						p2Points++;
                }
                else
                {
                    if (tmp1 < 3)
                    {
                        tmp1++;
                        p1Points = points[tmp1];
                    }
                    else
                        p1Points++;
                }
            }
        }

        if (p1Points > p2Points)
            this.p1Gems++;
        else
            this.p2Gems++;
    }

    private void playTieBreak()
    {
        int p1Points = 0;
        int p2Points = 0;
        boolean turn = true;

        while ((p1Points < 7 && p2Points < 7) || Math.abs(p1Points - p2Points) < 2)
        {
			if (turn)
			{
				if (this.chanceEvent(this.p1.servePointChance(this.p2, this.matchSurface)))
					p1Points++;
				else
					p2Points++;
			}
			else
			{
				if (this.chanceEvent(this.p2.servePointChance(this.p1, this.matchSurface)))
					p1Points++;
				else
					p1Points++;
			}

			turn = !turn;
        }	

        if (p1Points > p2Points)
			this.p1Gems++;
        else
			this.p2Gems++;
    }	

    private boolean chanceEvent(int probability)
    {
        return 1 + this.rng.nextInt(100) <= probability;
    }

    public void printMatchResult()
    {
        int i;
		int l1 = this.p1.getName().length();
		int l2 = this.p2.getName().length();
		int tmp = Math.abs(l1 - l2); 
		
        System.out.print(this.p1.getName() + "   ");
		if (l2 > l1)
		{
			for (i = 0; i < tmp; i++)
				System.out.print(" ");
		}
        for (i = 0; i <= this.p1Sets + this.p2Sets - 1; i++)
			System.out.print(this.p1ScorePerSet[i] + " ");
        System.out.println(" |  " + this.p1Sets);

        System.out.print(this.p2.getName() + "   ");
		if (l1 > l2)
		{
			for (i = 0; i < tmp; i++)
				System.out.print(" ");
		}
        for (i = 0; i <= this.p1Sets + this.p2Sets - 1; i++)
			System.out.print(this.p2ScorePerSet[i] + " ");
        System.out.println(" |  " + this.p2Sets);
		
		
		if (p1.getInjured())
			System.out.println("Due the injury of " + p1.getName() + ", the winner of this match is " + p2.getName() + ".");
		else if(p2.getInjured())
			System.out.println("Due the injury of " + p2.getName() + ", the winner of this match is " + p1.getName() + ".");
		
		System.out.println();
    }
}
