package atp_tour;

/**
 *
 * @author Dejan Pejic
 */
public class Player implements Comparable<Player>
{
    private String name;
    private String ability;
    private String preferedSurface;
    private int atpRank;
    private int atpPoints;
    private boolean injured;

    public Player()
    {
            this.name = "Boba Zivojinovic";
            this.ability = "servis";
            this.preferedSurface = "hard";
            this.atpRank = 0;
            this.atpPoints = 0;
            this.injured = false;
    }

    public Player(String name, String ability, String preferedSurface, int atpRank, int atpPoints)
    {
            this.name = name;
            this.ability = ability;
            this.preferedSurface = preferedSurface;
            this.atpRank = atpRank;
            this.atpPoints = atpPoints;
            this.injured = false;
    }

    public String getName()
    {
            return name;
    }

    public void setName(String name)
    {
            this.name = name;
    }

    public String getAbility()
    {
            return ability;
    }

    public void setAbility(String ability)
    {
            this.ability = ability;
    }

    public String getPreferedSurface()
    {
            return preferedSurface;
    }

    public void setPreferedSurface(String preferedSurface)
    {
            this.preferedSurface = preferedSurface;
    }

    public int getAtpRank()
    {
            return atpRank;
    }

    public void setAtpRank(int atpRank)
    {
            this.atpRank = atpRank;
    }

    public int getAtpPoints()
    {
            return atpPoints;
    }

    public void setAtpPoints(int atpPoints)
    {
            this.atpPoints = atpPoints;
    }

    public boolean getInjured()
    {
            return injured;
    }

    public void setInjured(boolean injured)
    {
            this.injured = injured;
    }

    public int servePointChance(Player opponent, String surface)
    {
        int chance = 50;

        switch (this.ability)
        {
            case "forehand":
                chance += 10;
                break;
            case "serve":
                chance += 15;
                break;
            case "mentality":
                chance += 5;
                break;
            default:
        }

        switch (opponent.getAbility())
        {
            case "backhand":
                chance -= 8;
                break;
            case "serve":
                chance += 5;
                break;
            case "mentality":
                chance -= 10;
                break;
            default:
        }

        if (this.preferedSurface.equals(surface))
            chance += 5;
            
        chance -= this.atpRank;
        chance += opponent.getAtpRank();

        return chance;
    }

    @Override
    public String toString()
    {
        String injury = injured ? " | (+)" : "";
        return atpRank + ". " + name + ", " + atpPoints + " Points" + injury;
    }
	
	@Override
    public int compareTo(Player pl) 
	{
        return Integer.compare(pl.atpPoints, this.atpPoints);
    }
}
