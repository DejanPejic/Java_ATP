package atp_tour;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Dejan Pejic
 */
public class Simulate
{
	public static void main(String[] args) throws FileNotFoundException, IOException
	{
		Championship chmp = new Championship();
		chmp.loadFiles();
		
		Scanner sc = new Scanner(System.in);
		
		int tournamentsNum;
		System.out.print("Enter the number of the season tournaments you want to be played on championship (4 - 13): ");
		do
		{
			try 
			{
                tournamentsNum = Integer.parseInt(sc.nextLine());
				if (tournamentsNum < 4 || tournamentsNum > 13)
					System.out.print("You entered a number that is outside the allowed range! Try again: ");
            } catch (NumberFormatException nfe) 
			{
                System.out.print("You entered a string! Try again: ");
				tournamentsNum = 0;
            }
		} while (tournamentsNum < 4 || tournamentsNum > 13);
		
		int nextTournament;
		int tournamentsSize = chmp.getTournaments().size();
		int i, j;
		for (i = 1; i <= tournamentsNum; i++)
		{
			System.out.println("\n\nList of the tournaments:");
			for (j = 0; j < tournamentsSize; j++)
				System.out.println((j + 1) + ". " + chmp.getTournaments().get(j));
			System.out.print("\nChoose the next tournament to be played (" + i + "/" + tournamentsNum + "): ");
			do
			{  
				try 
				{
					nextTournament = Integer.parseInt(sc.nextLine());
					if (nextTournament < 1 || nextTournament > tournamentsSize)
						System.out.print("You entered a not available number! Try again: ");
					else if (!chmp.getTournaments().get(nextTournament - 1).getPlayable())
						System.out.print("This tournament has already been played! Try again: ");
				} catch (NumberFormatException nfe) 
				{
					System.out.print("You entered a string! Try again: ");
					nextTournament = 0;
				}
			} while (nextTournament < 1 || nextTournament > tournamentsSize || 
					 !chmp.getTournaments().get(nextTournament - 1).getPlayable());
			
			System.out.println("\n---------- " + chmp.getTournaments().get(nextTournament - 1).getTourName() + " ----------\n");
			chmp.getTournaments().get(nextTournament - 1).play();
			chmp.updateAtpRanks();
			System.out.println("########## ATP List ##########");
			for (Player pl: chmp.getPlayers())
				System.out.println(pl);
			chmp.recoverPlayers();
			chmp.getTournaments().get(nextTournament - 1).setPlayable(false);
		}
		
		System.out.println("\nAll selected seasonal tournaments have been completed.");
		System.out.print("Confirm to start ATP Final tournament (enter anything): ");
		sc.nextLine();
		
		Tournament ft = new AtpFinals(chmp.getPlayers());
			chmp.getTournaments().add(ft);
		System.out.println("\n---------- " + chmp.getTournaments().get(tournamentsSize).getTourName() + " ----------\n");
		chmp.getTournaments().get(tournamentsSize).play();
		chmp.updateAtpRanks();
		System.out.println("########## ATP List ##########");
		for (Player pl: chmp.getPlayers())
			System.out.println(pl);
		chmp.recoverPlayers();
		chmp.getTournaments().get(tournamentsSize).setPlayable(false);
		System.out.println("\n*** " + chmp.getPlayers().get(0).getName() + " is the first at the end of the year! ***");
	}
}
