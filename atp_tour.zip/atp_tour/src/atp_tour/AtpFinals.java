package atp_tour;

import java.util.ArrayList;

/**
 *
 * @author Dejan Pejic
 */
public class AtpFinals extends Tournament
{
	private ArrayList<Player> groupA;
	private ArrayList<Player> groupB;
	private ArrayList<Player> semiFinalists;
	private ArrayList<Player> finalists;
	
	public AtpFinals(ArrayList<Player> players)
	{
		super("ATP Finals", "ATP Finals", "hard", true);
		
		this.groupA = new ArrayList<>();
		this.groupB = new ArrayList<>();
		for (int i = 0; i < 4; i++)
		{
			this.groupA.add(players.get(2*i));
			this.groupB.add(players.get(2*i + 1));
		}
		
		this.semiFinalists = new ArrayList<>();
		this.finalists = new ArrayList<>();
	}
	
	@Override
	public void play()
	{
		this.playGroupA();
		this.playGroupB();
		this.playSemiFinals();
		this.playFinal();
	}
	
	private void playGroupA()
	{
		Match match;
		Player winner;
		int winPoints = 200;
		int[] groupPoints = {0, 0, 0, 0};
		int i, j;
		
		System.out.println("=== ATP Finals - Group A ===");
		for(i = 0; i < 4; i++)
		{
			groupA.get(i).setAtpRank(i);
			System.out.println(groupA.get(i).getName());
		}
		System.out.println();
		
		for (i = 0; i < 3; i++)
		{
			for (j = i + 1; j < 4; j++)
			{
				match = new Match(groupA.get(i), groupA.get(j), "hard", 2);
				winner = match.playMatch();
				winner.setAtpPoints(winner.getAtpPoints() + winPoints);
				groupPoints[winner.getAtpRank()]++;
			}
		}
		
		int first = 0, second = 1;
		for (i = 1; i < 4; i ++)
		{
			if (groupPoints[i] > groupPoints[first])
			{
				second = first;
				first = i;
			}
			else if (groupPoints[i] > groupPoints[second])
				second = i;
		}
		
		semiFinalists.add(groupA.get(first));
		semiFinalists.add(groupA.get(second));
	}
	
	private void playGroupB()
	{
		Match match;
		Player winner;
		int winPoints = 200;
		int[] groupPoints = {0, 0, 0, 0};
		int i, j;
		
		System.out.println("=== ATP Finals - Group B ===");
		for(i = 0; i < 4; i++)
		{
			groupB.get(i).setAtpRank(i);
			System.out.println(groupB.get(i).getName());
		}
		System.out.println();
		
		for (i = 0; i < 3; i++)
		{
			for (j = i + 1; j < 4; j++)
			{
				match = new Match(groupB.get(i), groupB.get(j), "hard", 2);
				winner = match.playMatch();
				winner.setAtpPoints(winner.getAtpPoints() + winPoints);
				groupPoints[winner.getAtpRank()]++;
			}
		}
		
		int first = 0, second = 1;
		for (i = 1; i < 4; i ++)
		{
			if (groupPoints[i] > groupPoints[first])
			{
				second = first;
				first = i;
			}
			else if (groupPoints[i] > groupPoints[second])
				second = i;
		}
		
		semiFinalists.add(groupB.get(first));
		semiFinalists.add(groupB.get(second));
	}
	
	private void playSemiFinals()
	{
		Match match;
		Player winner;
		int winPoints = 400;
		
		System.out.println("==== ATP Finals - Semi Finals ====");
		System.out.println(semiFinalists.get(0).getName() + " vs " + semiFinalists.get(3).getName());
		System.out.println(semiFinalists.get(2).getName() + " vs " + semiFinalists.get(1).getName());
		System.out.println();
		
		match = new Match(semiFinalists.get(0), semiFinalists.get(3), "hard", 2);
		winner = match.playMatch();
		winner.setAtpPoints(winner.getAtpPoints() + winPoints);
		finalists.add(winner);
		
		match = new Match(semiFinalists.get(2), semiFinalists.get(1), "hard", 2);
		winner = match.playMatch();
		winner.setAtpPoints(winner.getAtpPoints() + winPoints);
		finalists.add(winner);
	}
	
	private void playFinal()
	{
		Match match;
		Player winner;
		int winPoints = 500;
		
		System.out.println("===== ATP Finals - Final =====");
		System.out.println(finalists.get(0).getName() + " vs " + finalists.get(1).getName());
		System.out.println();
		
		match = new Match(finalists.get(0), finalists.get(1), "hard", 2);
		winner = match.playMatch();
		winner.setAtpPoints(winner.getAtpPoints() + winPoints);
		System.out.println(winner.getName() + " won the ATP Finals! Congratulations!\n");
	}
}	
